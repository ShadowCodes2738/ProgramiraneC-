﻿using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Business
{
    public class BirdsDBBusiness
    {
            private BirdsDBContext birdsDBContext;
            public List<Bird> GetAllBirds()
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    return birdsDBContext.Birds.ToList();
                }
            }
            public Bird GetBird(int id)
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    return birdsDBContext.Birds.Find(id);
                }
            }

            public void AddBird(Bird bird)
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    birdsDBContext.Birds.Add(bird);
                    birdsDBContext.SaveChanges();
                }

            }

            public void UpdateBird(Bird bird)
            {
                using (birdsDBContext = new BirdsDBContext())
                {

                    var item = birdsDBContext.Birds.Find(bird.Id);
                    if (item != null)
                    {
                        birdsDBContext.Entry(item).CurrentValues.SetValues(bird);
                        birdsDBContext.SaveChanges();

                    }

                }
            }
        public void DeleteBird(int id)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                var bird = birdsDBContext.Birds.Find(id);
                if (bird != null)
                {
                    birdsDBContext.Birds.Remove(bird);
                    birdsDBContext.SaveChanges();

                }

            }
        }



        }
    }

