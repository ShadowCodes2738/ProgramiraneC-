﻿using Data;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Business
{
    public class BirdsDBBusiness
    {
            private BirdsDBContext birdsDBContext;
            public List<Bird> GetAllBirds()
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    return birdsDBContext.Birds.ToList();
                }
            }
            public Bird GetBird(int id)
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    return birdsDBContext.Birds.Find(id);
                }
            }

            public void AddBird(Bird bird)
            {
                using (birdsDBContext = new BirdsDBContext())
                {
                    birdsDBContext.Birds.Add(bird);
                    birdsDBContext.SaveChanges();
                }

            }

            public void UpdateBird(Bird bird)
            {
                using (birdsDBContext = new BirdsDBContext())
                {

                    var item = birdsDBContext.Birds.Find(bird.Id);
                    if (item != null)
                    {
                        birdsDBContext.Entry(item).CurrentValues.SetValues(bird);
                        birdsDBContext.SaveChanges();

                    }

                }
            }
        public void DeleteBird(int id)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                var bird = birdsDBContext.Birds.Find(id);
                if (bird != null)
                {
                    birdsDBContext.Birds.Remove(bird);
                    birdsDBContext.SaveChanges();

                }

            }
        }

      

        public List<Observer> GetAllObserver()
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                return birdsDBContext.Observers.ToList();
            }
        }
        public Observer GetObserver(int id)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                return birdsDBContext.Observers.Find(id);
            }
        }
        public void AddObserver(Observer observer)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                birdsDBContext.Observers.Add(observer);
                birdsDBContext.SaveChanges();
            }

        }
        public void UpdateObserver(Observer observer)
        {
            using (birdsDBContext = new BirdsDBContext())
            {

                var item = birdsDBContext.Observers.Find(observer.Id);
                if (item != null)
                {
                    birdsDBContext.Entry(item).CurrentValues.SetValues(observer);
                    birdsDBContext.SaveChanges();

                }

            }
        }
        public void DeleteObserver(int id)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                var observer = birdsDBContext.Observers.Find(id);
                if (observer != null)
                {
                    birdsDBContext.Observers.Remove(observer);
                    birdsDBContext.SaveChanges();

                }

            }
        }




        public List<Sighting> GetAllSightings()
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                return birdsDBContext.Sightings.ToList();
            }
        }
        public Sighting GetSightings(int id)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                return birdsDBContext.Sightings.Find(id);
            }
        }
        public void AddSightings(Sighting sighting)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                birdsDBContext.Sightings.Add(sighting);
                birdsDBContext.SaveChanges();
            }

        }
        public void UpdateSighting(Sighting sighting)
        {
            using (birdsDBContext = new BirdsDBContext())
            {

                var item = birdsDBContext.Sightings.Find(sighting.Id);
                if (item != null)
                {
                    birdsDBContext.Entry(item).CurrentValues.SetValues(sighting);
                    birdsDBContext.SaveChanges();

                }

            }
        }
        public void DeleteSighting(int id)
        {
            using (birdsDBContext = new BirdsDBContext())
            {
                var sighting = birdsDBContext.Sightings.Find(id);
                if (sighting != null)
                {
                    birdsDBContext.Sightings.Remove(sighting);
                    birdsDBContext.SaveChanges();

                }

            }
        }
    }
    }

