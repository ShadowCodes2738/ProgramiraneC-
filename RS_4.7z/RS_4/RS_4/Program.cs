﻿using Data;
using System;

namespace RS_4
{
    class Program
    {
        static void Main(string[] args)
        {
            BirdsDBContext cont = new BirdsDBContext();
        }
    }
}
