﻿using System;
using Data.Model;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Data
{
    public class BirdsDBContext : DbContext
    {
        public BirdsDBContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
        {
            optionBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BirdDB");
        }
        public DbSet<Bird> Birds { get; set; }
        public DbSet<Observer> Observers  {get; set; }
        public DbSet<Sighting> Sightings  {get; set; }
        public DbSet<SightingBird> SightingBirds { get; set; }
    }
}
