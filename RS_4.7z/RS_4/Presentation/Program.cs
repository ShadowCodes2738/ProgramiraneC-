﻿using System;

namespace Presentation
{
    class Program
    {
        static void Main(string[] args)

        {
            Display display = new Display();
        }
    }

}